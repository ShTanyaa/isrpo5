﻿using Dogs.Models;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Dogs.Views;

namespace Dogs
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Page[] pages;
        private List<Dog> dogs = new List<Dog>
{
    new Dog
    {
        Country = "Russia",
        Name = "Hartley Devils Izumrud",
        NameHome="Hartley Devils",
        Description = "JGrCH.RUS, JCH.RKF, JCH.RUS, JCH.CL RUS",
        Population = 0,
        PhotoUrl = "https://sun9-1.userapi.com/impf/RX_zMHPAhyQRgDQg64xgeClNGoz94m_AQB1INA/FlNiCcj7Xzw.jpg?size=1600x1066&quality=96&sign=70ac575b1b757d1502cea4e155b7df90&type=album",
        Patella="N/N"
    },
    new Dog
    {
        Country = "Russia",
        Name = "Hartley Devils Checlava",
         NameHome="Hartley Devils",
        Description = "JGrCH.RUS, JCH.RKF, JCH.RUS, JCH.CL RUS,GrCH.RUS, CH.RUS, CH.CL RUS",
        Population = 15,
        PhotoUrl = "https://zooportal.pro/upload/iblock/203/vmv9a4wywrl1lya5p0qxh5nru4py516t.jpeg",
        Patella="N/N"
    },
    new Dog
    {
        Country = "Russia",
        Name = "Inter Win Iris",
         NameHome="Inter Win",
        Description = "JGrCH.RUS, JCH.RKF, JCH.RUS, JCH.CL RUS,CH.RUS",
        Population = 20,
        PhotoUrl = "https://sun9-5.userapi.com/impg/fhS1gsuHtxdnE04J29x_c2ig1-wiSsl8bCmpuQ/C1XmjFnaC5I.jpg?size=2560x1709&quality=95&sign=116472979d4913e0cebbc33a266d9d2a&type=album",
        Patella="N/N"
    }
    
};
        public MainWindow()
        {
            InitializeComponent();
            pages = new Page[]
   {
        new ListBoxPage(dogs)
   };
            pagesComboBox.ItemsSource = pages;
            pagesComboBox.DisplayMemberPath = "Title";
        }
        private void SelectWindow(object sender, SelectionChangedEventArgs e)
        {
            Page? page = pagesComboBox.SelectedItem as Page;
            mainFrame.Navigate(page);
        }
    }
}